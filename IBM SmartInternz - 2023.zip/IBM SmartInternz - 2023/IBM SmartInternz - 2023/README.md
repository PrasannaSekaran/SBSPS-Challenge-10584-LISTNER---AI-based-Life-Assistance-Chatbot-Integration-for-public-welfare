

**VBOT ( VoiceBot ):**
This Folder consists of main webpage( index1.html ) and voice bot(templates/index.html) page

**app.py**: This python file consists of Voicebot's model

Softawares Required to open "edoc-doctor-appointment-system-main ":

**XAMPP Control Panel :**
https://www.apachefriends.org/download.html 

1) Install XAMPP Control Panel and Start the APACHE and MySQL Servers
2) Open any browser and copy this below url:
    http://localhost/phpmyadmin/
3) Create a New Database by clicking New section and import the Database file (SQL_Database_edoc) which is present inside the "edoc-doctor-appointment-system-main " folder
4) Copy the "edoc-doctor-appointment-system-main" folder to XAMPP directory, paste this folder inside the "htdocs" folder which is present inside the XAMPP directory
5) Copy the path of folderpath by clicking the path section. for example:
    D:\xamppp\htdocs\edoc-doctor-appointment-system-main
6) Paste this folder in the browser by modifying the above path like below:
    http://localhost/edoc-doctor-appointment-system-main/
7) Run the Website and you will be directed to thee Doctor Appointment System
